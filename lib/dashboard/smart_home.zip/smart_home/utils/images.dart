/// Icons
const ic_dashboard = 'images/dashboard/smart_home/ic_dashboard.png';
const ic_alert = 'images/dashboard/smart_home/ic_alert.png';
const ic_profile = 'images/dashboard/smart_home/ic_profile.png';
const ic_home_setting = 'images/dashboard/smart_home/ic_home_setting.png';
const ic_rainy_day = 'images/dashboard/smart_home/ic_rainy_day.png';
const ic_thunderbolt = 'images/dashboard/smart_home/ic_thunderbolt.png';
const ic_dollar = 'images/dashboard/smart_home/ic_dollar.png';
const ic_bedroom = 'images/dashboard/smart_home/ic_bedroom.png';
const ic_kitchen = 'images/dashboard/smart_home/ic_kitchen.png';
const ic_bulb = 'images/dashboard/smart_home/ic_bulb.png';
const ic_fan = 'images/dashboard/smart_home/ic_fan.png';
const ic_air_conditioner = 'images/dashboard/smart_home/ic_air_conditioner.png';

/// Images
