import 'package:flutter/material.dart';

const primaryHomeColor1 = Color(0xFF8FD6E3);
const roomCustomSkinColor = Color(0xFFE18F91);
const deviceCustomPurpleColor = Color(0xFFAF88D0);
const deviceCustomYellowColor = Color(0xFFD5BE88);
const bottomNavBarIconColor = Color(0xFFADB5BD);
